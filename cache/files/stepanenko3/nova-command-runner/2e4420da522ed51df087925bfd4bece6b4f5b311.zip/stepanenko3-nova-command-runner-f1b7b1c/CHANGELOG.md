# Release Notes

## [4.1.0](#)
- `Stepanenko3\NovaCommandRunner\CommandRunner` migrate to `Stepanenko3\NovaCommandRunner\CommandRunnerTool`

## [4.0.0](#)

- Compatible with Nova 4.0
- Drop compability with Nova 3
- Dark mode compatibility
- Responsive
- Use Nova Vue components
- Migrate to Vue 3 and Tailwind 3
- Bug fixes
