 import AppLogo from './components/AppLogo'

Nova.booting(app => {
  app.component('AppLogo', AppLogo)
})
