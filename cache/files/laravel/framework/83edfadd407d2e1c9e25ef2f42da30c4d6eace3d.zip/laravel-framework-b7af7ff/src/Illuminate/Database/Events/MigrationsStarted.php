<?php

namespace Illuminate\Database\Events;

class MigrationsStarted extends MigrationsEvent
{
    //
}
