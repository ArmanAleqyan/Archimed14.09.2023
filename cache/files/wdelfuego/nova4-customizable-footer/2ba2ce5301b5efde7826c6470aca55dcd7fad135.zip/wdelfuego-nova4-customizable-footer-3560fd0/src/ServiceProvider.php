<?php

namespace Wdelfuego\Nova4\CustomizableFooter;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;
use Laravel\Nova\Nova;

class ServiceProvider extends BaseServiceProvider
{

}
