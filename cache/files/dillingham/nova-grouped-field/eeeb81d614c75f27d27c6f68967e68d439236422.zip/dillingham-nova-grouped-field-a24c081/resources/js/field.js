Nova.booting((Vue, router) => {
    Vue.component('index-nova-grouped-field', require('./components/IndexField'));
    Vue.component('detail-nova-grouped-field', require('./components/DetailField'));
})
